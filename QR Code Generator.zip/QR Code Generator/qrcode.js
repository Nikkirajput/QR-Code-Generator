let inpt = document.querySelector("input")
let btn = document.querySelector("button")
let img = document.querySelector("img")
let span = document.querySelector("span")
let imgdiv = document.getElementById("imgdiv")
btn.addEventListener("click",()=>{
    if (inpt.value === ""){
        alert("please enter the text or URL")
    }
    else{
        img.src = ` https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${inpt.value}`
        imgdiv.style.display = 'flex'
        span.style.display = 'none'
        inpt.style.display = 'none'
    }
})

